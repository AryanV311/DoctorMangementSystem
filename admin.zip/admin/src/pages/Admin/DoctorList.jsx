

export const DoctorList = () => {
  return (
    <div>DoctorList</div>
  )
}
