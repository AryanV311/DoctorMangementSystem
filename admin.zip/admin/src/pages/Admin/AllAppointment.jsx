
export const AllAppointment = () => {
  return (
    <div>AllAppointment</div>
  )
}
